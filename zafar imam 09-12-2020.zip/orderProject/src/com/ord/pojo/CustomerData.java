package com.ord.pojo;

import java.util.ArrayList;

public class CustomerData {
	static ArrayList<CustomerVo> customer;
	public ArrayList<CustomerVo> dataInsert()
	{
		ArrayList<CustomerVo> customer=new ArrayList<>();
		CustomerVo obj=new CustomerVo();
		CustomerVo obj1=new CustomerVo();
		CustomerVo obj2=new CustomerVo();
		CustomerVo obj3=new CustomerVo();
		CustomerVo obj4=new CustomerVo();
		CustomerVo obj5=new CustomerVo();
		CustomerVo obj6=new CustomerVo();
		CustomerVo obj7=new CustomerVo();
		CustomerVo obj8=new CustomerVo();
		CustomerVo obj9=new CustomerVo();
		obj1.setName("Zafar imam");
		obj1.setAddress("delhi");
		obj1.setPhoneNumber("+917032871006");
		customer.add(obj1);
		obj2.setName("Rehan khan");
		obj2.setAddress("hyderabad");
		obj2.setPhoneNumber("+9170332871006");
		customer.add(obj2);
		obj3.setName("Rehan khan");
		obj3.setAddress("hyderabad");
		obj3.setPhoneNumber("+9170332871006");
		customer.add(obj3);
		obj4.setName("kiran kumari");
		obj4.setAddress("kalkaji madir");
		obj4.setPhoneNumber("+9172871006");
		customer.add(obj4);
		obj5.setName("shobit sharma");
		obj5.setAddress(" green grarden ");
		obj5.setPhoneNumber("+91232442");
		customer.add(obj5);
		obj6.setName("abhimayu");
		obj6.setAddress("greater noida");
		obj6.setPhoneNumber("+91728712206");
		customer.add(obj6);
		obj7.setName("abhiral");
		obj7.setAddress("Faridabad");
		obj7.setPhoneNumber("+91723236");
		customer.add(obj7);
		obj8.setName("arti");
		obj8.setAddress("neharu place");
		obj8.setPhoneNumber("+917287132306");
		customer.add(obj8);
		obj9.setName("rasika ");
		obj9.setAddress("kalkaji madir");
		obj9.setPhoneNumber("+917283206");
		customer.add(obj9);
		obj.setName("yash ");
		obj.setAddress("delhi near to anywhere");
		obj.setPhoneNumber("+917287232");
		customer.add(obj);
		
	
		return customer;
	}
//	public static void main(String[] args) {
//		CustomerData obj=new CustomerData();
//		 customer=new ArrayList<>();
//		
//		customer=obj.dataInsert();
//		CustomerVo obbj=customer.get(0);
//		System.out.println("================1user details============================ :");
//		System.out.println(obbj.getName());
//		System.out.println(obbj.getAddress());
//		System.out.println(obbj.getPhoneNumber());
//		CustomerVo ob2j=customer.get(1);
//		System.out.println("============================2nduser details=============== :");
//		System.out.println(ob2j.getName());
//		System.out.println(ob2j.getAddress());
//		System.out.println(ob2j.getPhoneNumber());
//		System.out.println("=============================3nduser details=============== :");
//		CustomerVo ob3j=customer.get(2);
//		System.out.println(ob3j.getName());
//		System.out.println(ob3j.getAddress());
//		System.out.println(ob3j.getPhoneNumber());
//		System.out.println("===========================4nduser details================== :");
//		CustomerVo ob4j=customer.get(3);
//		System.out.println(ob4j.getName());
//		System.out.println(ob4j.getAddress());
//		System.out.println(ob4j.getPhoneNumber());
//		System.out.println("==========================5nduser details==================== :");
//		CustomerVo ob5j=customer.get(4);
//		System.out.println(ob5j.getName());
//		System.out.println(ob5j.getAddress());
//		System.out.println(ob5j.getPhoneNumber());
//		System.out.println("========================6nduser details====================== :");
//		CustomerVo ob6j=customer.get(5);
//		System.out.println(ob6j.getName());
//		System.out.println(ob6j.getAddress());
//		System.out.println(ob6j.getPhoneNumber());
//		System.out.println("=======================7nduser details======================= :");
//		CustomerVo ob7j=customer.get(6);
//		System.out.println(ob7j.getName());
//		System.out.println(ob7j.getAddress());
//		System.out.println(ob7j.getPhoneNumber());
//		
//		System.out.println("=====================8nduser details========================= :");
//		CustomerVo ob8j=customer.get(7);
//		System.out.println(ob8j.getName());
//		System.out.println(ob8j.getAddress());
//		System.out.println(ob8j.getPhoneNumber());
//		System.out.println("=====================9nduser details========================= :");
//		CustomerVo ob9j=customer.get(8);
//		System.out.println(ob9j.getName());
//		System.out.println(ob9j.getAddress());
//		System.out.println(ob9j.getPhoneNumber());
//		System.out.println("=====================10nduser details========================= :");
//		CustomerVo ob10j=customer.get(9);
//		System.out.println(ob10j.getName());
//		System.out.println(ob10j.getAddress());
//		System.out.println(ob10j.getPhoneNumber());
//		
		
		
		
		
		
		
				
	//}

}
