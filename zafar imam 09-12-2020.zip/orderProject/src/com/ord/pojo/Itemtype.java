package com.ord.pojo;

public abstract class Itemtype {
	 abstract	public void vegItem();
	 abstract public void nonVegItem();

}
