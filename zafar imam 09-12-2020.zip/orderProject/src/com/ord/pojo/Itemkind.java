package com.ord.pojo;

public interface Itemkind {
	double Malai_Kofta=500.00;
	double PalakP_Paneer=600.00;
	double Rajma=700.00;
	double Mutter_Paneer=300.00;
	double Kaali_Daal=150.00;
	double Chole=100.00;
	double Aaloo_Paratha=100.00;
	double Hara_Bhara_Kabab=180.00;
	double Daal_Palak=160.00;
	double Ice_cream=150.00;
	double Grilled_Chicken=180.00;
	double Mutton_Korma=300.00;
	double  Pina_Colada=200.00;
	double 	Lamb_Chops=300.00;
	double Malabar_Fish_Biryani=200.00;
	double Pina_Colada_Pork_Ribs=200.00;
	double Tandoori_Lamb_Chops=300.00;
	double Malabar_Fish_Curry=150.00;
	double Keema_Samosa_with_Yoghurt_Dip=200.00;
	double Curried_Parmesan_Fish_Fingers=190.00;
	double Chicken_65=160.00;
	double Butter_Chicken=180.00;
	
	

}
