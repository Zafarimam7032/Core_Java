package com.ord.pojo;

public interface orderReceipt {
	 public void vegrecipt();
	 public void nonvegrecipt();

}
